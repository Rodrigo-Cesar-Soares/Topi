package app.modelo.meusclientes.model;

public class Items {

    public String name;
    public String full_name;
    public String description;
    public int forks;

    public Items(String name, String full_name, String description, int forks, int watchers) {
        this.name = name;
        this.full_name = full_name;
        this.description = description;
        this.forks = forks;
        this.watchers = watchers;
    }

    public int watchers;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFull_name() {
        return full_name;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getForks() {
        return forks;
    }

    public void setForks(int forks) {
        this.forks = forks;
    }

    public int getWatchers() {
        return watchers;
    }

    public void setWatchers(int watchers) {
        this.watchers = watchers;
    }


}
