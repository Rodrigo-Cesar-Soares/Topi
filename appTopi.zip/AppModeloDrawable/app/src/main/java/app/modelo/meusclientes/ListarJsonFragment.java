package app.modelo.meusclientes;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import app.modelo.meusclientes.model.Items;
import app.modelo.meusclientes.model.ListaItems;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class ListarJsonFragment extends Fragment {

    public static final String TAG = "Rodrigo";

    View view;

    EditText editPesquisarNome;
    ListView listView;

    List<Items> itemsList;
    List<String> items;
    List<String> dados;

    ArrayAdapter<String> dadosAdapter;
    ArrayList<HashMap<String, String>> filtroDados;

    public ListarJsonFragment() {
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view =  inflater.inflate(R.layout.fragment_listar_json, container, false);

        TextView txtTitulo = view.findViewById(R.id.txtTitulo);

        txtTitulo.setText(R.string.listar_json_fragment);
        txtTitulo.setTextColor(ColorStateList.valueOf(Color.WHITE));


        listView = (ListView) view.findViewById(R.id.listView);
        editPesquisarNome = view.findViewById(R.id.editPesquisarNome);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Service.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        //retornando uma classe que implementa a interface service ** polimorfismo **
        Service service = retrofit.create(Service.class);
        Call<ListaItems> requestItems = service.listItems();

        requestItems.enqueue(new Callback<ListaItems>() {
            @Override
            public void onResponse(Call<ListaItems> call, Response<ListaItems> response) {
                // senão retornou com sucesso
                if(!response.isSuccess()) {
                    Log.i(TAG,"Erro: " + response.code());
                }
                else {
                    // Requisição retornou com sucesso !!!
                    ListaItems lista = response.body();

                    dados = new ArrayList<>();

                    for(Items c: lista.items){
                        Log.i(TAG,String.format("%s: %s: %s: %s: %s",c.name,c.full_name,c.description,c.forks,c.watchers));

                        Log.i(TAG,"---------------");
                        dados.add("Nome: "+c.name+"\nDescrição: "+c.description+"\nVisual: "+c.watchers+"  Curtidas: "+c.forks);
                    }

                    dadosAdapter = new ArrayAdapter<>(getContext(), R.layout.listar_json_item, R.id.txtItemJson, dados);
                    listView.setAdapter(dadosAdapter);

                    editPesquisarNome.addTextChangedListener(new TextWatcher() {
                        @Override
                        public void beforeTextChanged(CharSequence filtro, int start, int count, int after) {
                            ListarJsonFragment.this.dadosAdapter.getFilter().filter(filtro);
                            Log.i("Filtro", "beforeTextChanged: "+filtro);
                        }

                        @Override
                        public void onTextChanged(CharSequence s, int start, int before, int count) {

                        }

                        @Override
                        public void afterTextChanged(Editable s) {

                        }
                    });

                }
            }

            @Override
            public void onFailure(Call<ListaItems> call, Throwable t) {
                Log.e(TAG,"Erro: " + t.getMessage());
            }
        });


        return view;
    }


}
