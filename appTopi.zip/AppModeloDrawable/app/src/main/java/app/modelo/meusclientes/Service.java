package app.modelo.meusclientes;

// Interface para acessar o endpoint:
// - https://api.github.com/search/repositories?q=language:Java&sort=stars&page=1

import retrofit2.Call;
import retrofit2.http.GET;
import app.modelo.meusclientes.model.ListaItems;

public interface Service {

    public static final String BASE_URL = "https://api.github.com/search/";

    @GET("repositories?q=language:Java&sort=stars&page=1")
    Call<ListaItems> listItems();

}
