package app.modelo.meusclientes.model;

import java.util.List;

public class ListaItems {

    public List<Items> items;

}
